import curses
import sys

def get_prefix(y):
    return f"{y+1:4} | "

def draw(stdscr, lines, y, x, offset_y, offset_x, filename):
    stdscr.erase()

    h, w = stdscr.getmaxyx()
    text_height = h - 1  # last line = status bar

    # ---- visible window ----
    for i in range(text_height):
        line_index = offset_y + i
        if line_index >= len(lines):
            break

        prefix = get_prefix(line_index)
        line = lines[line_index]
        
        # Calculate how much space is left for text after rendering line numbers
        available_width = w - len(prefix) - 1
        
        # Slice the line using both offset_x and the available screen width
        visible_text = line[offset_x : offset_x + available_width]

        stdscr.addstr(i, 0, prefix + visible_text)

    # ---- status bar ----
    status = f"{filename} | Ctrl+S Save | ESC Exit | Ln {y+1}, Col {x+1}"
    stdscr.addstr(h - 1, 0, status[:w - 1], curses.A_REVERSE)

    # ---- FIX CURSOR POSITION (with vertical and horizontal scroll) ----
    screen_y = y - offset_y
    screen_x = (x - offset_x) + len(get_prefix(y))
    stdscr.move(screen_y, screen_x)

    stdscr.refresh()


def main(stdscr, filename):
    curses.curs_set(1)
    stdscr.keypad(True)

    try:
        with open(filename, "r") as f:
            lines = f.read().splitlines()
    except:
        lines = [""]

    y, x = 0, 0
    offset_y = 0
    offset_x = 0  # Track horizontal scroll position

    while True:
        h, w = stdscr.getmaxyx()
        text_height = h - 1
        
        # Calculate available width dynamically each frame
        prefix_len = len(get_prefix(y))
        available_width = w - prefix_len - 1

        # ---- AUTO SCROLL DOWN ----
        if y >= offset_y + text_height:
            offset_y = y - text_height + 1

        # ---- AUTO SCROLL UP ----
        if y < offset_y:
            offset_y = y

        # ---- AUTO SCROLL RIGHT ----
        if x >= offset_x + available_width:
            offset_x = x - available_width + 1

        # ---- AUTO SCROLL LEFT ----
        if x < offset_x:
            offset_x = x

        draw(stdscr, lines, y, x, offset_y, offset_x, filename)

        key = stdscr.getch()

        # ---- EXIT ----
        if key == 27:
            break

        # ---- SAVE ----
        elif key == 19:
            with open(filename, "w") as f:
                f.write("\n".join(lines))

        # ---- ENTER ----
        elif key in (10, 13):
            new_line = lines[y][x:]
            lines[y] = lines[y][:x]
            lines.insert(y + 1, new_line)
            y += 1
            x = 0

        # ---- BACKSPACE ----
        elif key in (8, 127):
            if x > 0:
                lines[y] = lines[y][:x - 1] + lines[y][x:]
                x -= 1
            elif y > 0:
                x = len(lines[y - 1])
                lines[y - 1] += lines[y]
                lines.pop(y)
                y -= 1

        # ---- MOVE UP ----
        elif key == curses.KEY_UP:
            if y > 0:
                y -= 1
                x = min(x, len(lines[y]))

        # ---- MOVE DOWN ----
        elif key == curses.KEY_DOWN:
            if y < len(lines) - 1:
                y += 1
                x = min(x, len(lines[y]))

        # ---- MOVE LEFT ----
        elif key == curses.KEY_LEFT:
            x = max(0, x - 1)

        # ---- MOVE RIGHT ----
        elif key == curses.KEY_RIGHT:
            x = min(len(lines[y]), x + 1)

        # ---- TYPE ----
        elif 32 <= key <= 126:
            lines[y] = lines[y][:x] + chr(key) + lines[y][x:]
            x += 1


if __name__ == "__main__":
    file = sys.argv[1] if len(sys.argv) > 1 else "untitled.txt"
    curses.wrapper(main, file)

